for($i=51;$i<91;$i++)
{
	print "sbatch j$i\n";
}
